rm(list=ls())
### requare packages and set work directory
library(MASS)
library(readr)
library(dplyr)
library(tidyr)
library(rstan)
library(brms)
library(loo)
# Sys.setenv(USE_CXX14 = 1)
# options(mc.cores = parallel::detectCores())
# rstan_options(auto_write = TRUE)
# basic MCMC parameter, should probably be a bit higher but we don't have all day!
niter = 2000 # numbers per chain, more is better (but takes longer)
nwarm = floor(niter/2) # bun-in period, these samples are not included in estimation
nchains = 4 # number of chains, usually at least 2

wd <- 'your director'
# output directory
OutPath <- file.path(RootPath,'TAziji_results')
if (!dir.exists(OutPath)) dir.create(OutPath)

setwd(wd)

############## Eye-trakcing data #####################
dat.e <- read.table('Taziji_eye_tracking.txt',sep='\t',header=T)

##### trial order
df.order <- data.frame(trial = unique(dat.e$trial),trialord = 1:length(unique(dat.e$trial)))
df.order <- df.order %>% mutate(tord = as.numeric(scale(trialord)))
dat.e <- inner_join(dat.e, df.order, by = c("trial" = "trial"))

dat.e <- dat.e %>% mutate(sub=as.factor(sub), item=as.factor(item), NP1=as.factor(NP1), NP2=as.factor(NP2), condition=as.factor(condition))
contrasts(dat.e$NP1) <- contr.sum(2)
contrasts(dat.e$NP2) <- contr.sum(2)

contrasts(dat.e$condition,3) <- cbind(NP2=c(0.5,0.5,-0.5,-0.5),LocalM=c(-0.5,0.5,0,0),LocalMis=c(0,0,0.5,-0.5))
# Matrix-m, local-m       0.5   0.5   0
# Matrix-mis, local-m     0.5  -0.5   0
# Matrix-m, local-mis    -0.5   0     0.5
# Matrix-mis, local-mis  -0.5   0    -0.5

# define IAs
IAs <- c('v1','taziji')
# define eye tracking measures
EVs <- c('IA_FIRST_FIXATION_DURATION','IA_FIRST_RUN_DWELL_TIME','IA_DWELL_TIME','IA_REGRESSION_PATH_DURATION')

## set prior
pr <- c(set_prior("normal(0,1)",class="b"),
        set_prior("normal(0,10)", class="Intercept"),
        set_prior("cauchy(0, 5)", class="sd"),
        set_prior('lkj(2)',class='cor'))

## IA level loop
for (ia in 1:length(IAs)) {
  IaNum <- as.character(IAs[ia])
  # output directory for the current IA
  OutPathIa <- file.path(OutPath,IaNum)
  if (!dir.exists(OutPathIa)) dir.create(OutPathIa)
  ### IA full name
  if (IaNum=='v1') IaFull <- 'Local verb'
  if (IaNum=='taziji') IaFull <- 'Reflexive'
  dat.ia <- subset(dat.e,IA_LABEL==IaNum)
  dat.ia.ffd <- subset(dat.ia,IA_FIRST_FIXATION_DURATION > 60 & IA_FIRST_FIXATION_DURATION < 800 & 
                           IA_FIRST_RUN_DWELL_TIME > 60 & IA_FIRST_RUN_DWELL_TIME < 1000 & 
                           IA_FIRST_FIX_PROGRESSIVE == 1 & IA_SKIP == 0)
  ## eye tracking measure level loop
  for (ev in 1:length(EVs)) {
    EvNum <- as.character(EVs[ev])
    # eye tracking measure abbreviation
    if (EvNum=='IA_FIRST_FIXATION_DURATION') EvAbr <- 'FFD'
    if (EvNum=='IA_FIRST_RUN_DWELL_TIME') EvAbr <- 'GD'
    if (EvNum=='IA_DWELL_TIME') EvAbr <- 'TRT'
    if (EvNum=='IA_REGRESSION_PATH_DURATION') EvAbr <- 'RPD'
    # write formula
    fml <- paste('log(',EvNum,') ~ condition +(1+condition|sub) + (1 + condition|item)',sep='')
    if (IaNum=='IA_DWELL_TIME') dat.brm <- subset(dat.ia,IA_DWELL_TIME>0)
    if (IaNum!='IA_DWELL_TIME') dat.brm <- dat.ia.ffd
    # fit bayesian LMM
    fit <- brm(formula=fml, 
               data=dat.brm, prior = pr, family = lognormal(),
               warmup=nwarm, iter=niter, chains=nchains, cores=nchains,
               control = list(adapt_delta = 0.95)) #, max_treedepth = 12
    save(fit,file=file.path(OutPathIa, paste('TAziji_brm_',IaNum,'_',EvAbr,'.RData',sep='')))
    
    ### plot
    ylimits <- c('b_conditionNP2','b_conditionLocalM','b_conditionLocalMis')
    
    stp <- stanplot(fit,pars=ylimits, type='intervals',prob_outer=0.95)
    
    ylimits <- ylimits[length(ylimits):1]
    ylabels <- c('Main effect of\nLocal Congruence','Interference\nwhen Local-match','Interference\nwhen Local-mismatch')
    ylabels <- ylabels[length(ylabels):1]
    
    stp <- stp + scale_y_discrete(limits=ylimits, labels=ylabels) + 
      theme(axis.text.x=element_text(size=rel(1.2)),axis.text.y=element_text(size=rel(0.8))) + 
      ggtitle(paste(IaFull,' - ',EvAbr,sep=''))
    # save plot
    ggsave(file.path(OutPathIa, paste('TAziji_brm_',IaNum,'_',EvAbr,'.png',sep='')),
           width=4.25,height=4.51,dpi=300)
  }}




